# Widget FB Pixel

Storefront plugin to handle Facebook Pixel events
