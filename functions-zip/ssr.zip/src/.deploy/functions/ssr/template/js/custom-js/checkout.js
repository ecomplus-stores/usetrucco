// Add your custom JavaScript for checkout here.
window.ecomDefaultPaymentApp = 111223
