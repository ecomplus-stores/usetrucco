import '#template/js/checkout'
import './custom-js/checkout'
import cartChange from '@ecomplus/shopping-cart'

window.ecomShippingApps = [111223, 1251, 1250]
